from django.db import models

# Create your models here.# books/models.py

from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)       # book name
    author = models.CharField(max_length=100)      # who wrote it
    isbn = models.CharField(max_length=13, unique=True)  # unique book ID
    published_date = models.DateField()
    is_available = models.BooleanField(default=True)  # is it available to borrow?

    def __str__(self):
        return self.title   # when you print a Book object, shows its title
