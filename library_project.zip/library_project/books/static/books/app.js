const API_URL = '/api/books/';
const bookForm = document.getElementById('bookForm');
const booksList = document.getElementById('booksList');
const totalCount = document.getElementById('totalCount');
const statusMessage = document.getElementById('statusMessage');
const clearButton = document.getElementById('clearButton');
const bookIdInput = document.getElementById('bookId');

function getCookie(name) {
  const cookieString = document.cookie || '';
  const cookies = cookieString.split(';').map((item) => item.trim());
  const found = cookies.find((cookie) => cookie.startsWith(`${name}=`));
  return found ? decodeURIComponent(found.split('=')[1]) : '';
}

function getCsrfToken() {
  const metaToken = document.querySelector('meta[name="csrf-token"]');
  return metaToken?.getAttribute('content') || getCookie('csrftoken');
}

function showMessage(message, type = 'success') {
  statusMessage.textContent = message;
  statusMessage.style.color = type === 'error' ? '#fda4af' : '#7dd3fc';
  setTimeout(() => {
    statusMessage.textContent = '';
  }, 4200);
}

function formatDate(value) {
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function renderBooks(books) {
  booksList.innerHTML = '';

  if (!books.length) {
    booksList.innerHTML = '<tr><td colspan="6" class="empty-row">No books found. Add a new book to get started.</td></tr>';
    totalCount.textContent = '0 books';
    return;
  }

  totalCount.textContent = `${books.length} book${books.length === 1 ? '' : 's'}`;

  books.forEach((book) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.isbn}</td>
      <td>${formatDate(book.published_date)}</td>
      <td><span class="badge ${book.is_available ? 'available' : 'unavailable'}">${book.is_available ? 'Available' : 'Unavailable'}</span></td>
      <td>
        <button class="action-btn edit" type="button" data-action="edit" data-id="${book.id}">Edit</button>
        <button class="action-btn delete" type="button" data-action="delete" data-id="${book.id}">Delete</button>
      </td>
    `;
    booksList.appendChild(row);
  });
}

async function fetchBooks() {
  try {
    const response = await fetch(API_URL);
    const data = await response.json();
    renderBooks(data);
  } catch (error) {
    booksList.innerHTML = '<tr><td colspan="6" class="empty-row">Unable to load books.</td></tr>';
    showMessage('Unable to load books.', 'error');
  }
}

function populateForm(book) {
  bookIdInput.value = book.id;
  document.getElementById('title').value = book.title;
  document.getElementById('author').value = book.author;
  document.getElementById('isbn').value = book.isbn;
  document.getElementById('publishedDate').value = book.published_date;
  document.getElementById('isAvailable').checked = book.is_available;
  showMessage('Loaded book for editing. Update fields and save.', 'success');
}

function clearForm() {
  bookIdInput.value = '';
  bookForm.reset();
  document.getElementById('isAvailable').checked = true;
}

async function createBook(payload) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCsrfToken(),
    },
    body: JSON.stringify(payload),
  });
  return response;
}

async function updateBook(bookId, payload) {
  const response = await fetch(`${API_URL}${bookId}/`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCsrfToken(),
    },
    body: JSON.stringify(payload),
  });
  return response;
}

async function deleteBook(bookId) {
  const response = await fetch(`${API_URL}${bookId}/`, {
    method: 'DELETE',
    headers: {
      'X-CSRFToken': getCsrfToken(),
    },
  });
  if (response.status === 204) {
    showMessage('Book deleted successfully.');
    fetchBooks();
  } else {
    showMessage('Failed to delete book.', 'error');
  }
}

bookForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const payload = {
    title: document.getElementById('title').value.trim(),
    author: document.getElementById('author').value.trim(),
    isbn: document.getElementById('isbn').value.trim(),
    published_date: document.getElementById('publishedDate').value,
    is_available: document.getElementById('isAvailable').checked,
  };

  const bookId = bookIdInput.value;
  try {
    const response = bookId ? await updateBook(bookId, payload) : await createBook(payload);
    if (!response.ok) {
      const data = await response.json();
      const message = data.detail || Object.values(data).flat().join(' ');
      showMessage(message || 'Unable to save book.', 'error');
      return;
    }

    clearForm();
    fetchBooks();
    showMessage(bookId ? 'Book updated successfully.' : 'Book added successfully.');
  } catch (error) {
    showMessage('Unable to save book.', 'error');
  }
});

clearButton.addEventListener('click', () => {
  clearForm();
});

booksList.addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;

  const bookId = button.dataset.id;
  const action = button.dataset.action;

  if (action === 'edit') {
    fetch(`${API_URL}${bookId}/`)
      .then((response) => response.json())
      .then(populateForm)
      .catch(() => showMessage('Unable to load book for edit.', 'error'));
  }

  if (action === 'delete') {
    if (window.confirm('Delete this book permanently?')) {
      deleteBook(bookId);
    }
  }
});

fetchBooks();
