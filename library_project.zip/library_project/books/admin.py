from django.contrib import admin
from .models import Book

# Register your models here.
@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'isbn', 'published_date', 'is_available')
    list_filter = ('is_available', 'published_date')
    search_fields = ('title', 'author', 'isbn')
